
// Example solution

//class Solution {
//    func twoSum(array: [Int], target: Int) -> [Int] {
//        var dictionary: [Int : Int] = [ : ]
//        var resultArray: [Int] = []
//
//        for (i, j) in array.enumerated() {
//            if let index = dictionary[target - j] {
//                resultArray.append(index)
//                resultArray.append(i)
//                return resultArray
//            }
//            dictionary[j] = i
//        }
//        return resultArray
//    }
//}
//
//let example = Solution()
//example.twoSum(array: [3, 7, 6, 8, 16, 5], target: 23)

// Lesson 1 Remove dublicates from sorted array

//func removeDublicates(input: inout[Int]) -> Int {
//    var last: Int?
//    var index: Int = 0
//
//    while index < input.count {
//        if input[index] == last {
//            input.remove(at: index)
//        } else {
//            last = input[index]
//            index += 1
//        }
//    }
//    return input.count
//}
//
//var array = [0, 0, 1, 1, 2, 3, 3, 3, 4, 4, 5, 5, 5, 5]
//removeDublicates(input: &array)
//print(array)

// Lesson 2 Find the shortest unsorted continuous subarray

//func findUnsortedSubarray(array: [Int]) -> Int {
//    var startBorder = 1
//    var endBorder = 0
//
//    let count = array.count
//
//    var minNumber = array[count - 1]
//    var maxNumder = array[0]
//
//    for (index, currentItem) in array.enumerated() {
//        maxNumder = max(maxNumder, currentItem)
//        if currentItem < maxNumder {
//            endBorder = index
//        }
////        print(endBorder)
//    }
//
//    for (index, _) in array.enumerated() {
//        minNumber = min(minNumber, array[count - 1 - index])
//        if array[count - 1 - index] > minNumber {
//            startBorder = count - 1 - index
//        }
//    }
//
//    return endBorder - startBorder + 1
//}
//
//var array = [1, 4, 2, 3, 2, 6]
//
//findUnsortedSubarray(array: array)
//findUnsortedSubarray(array: [3, 2, 1, 5, 10])
//findUnsortedSubarray(array: [1, 1])

// Lesson 3 Reverse string

//func reverseString(string: inout [Character]) {
//    var lastItem = string.count - 1
//    var firstItem = 0
//
//    while firstItem < lastItem {
//        //        let temp = string[firstItem]
//        //        string[firstItem] = string[lastItem]
//        //        string[lastItem] = temp
//        (string[firstItem], string[lastItem]) = (string[lastItem], string[firstItem])
//        firstItem += 1
//        lastItem -= 1
//    }
//}
//
//var charArray: [Character] = ["G", "o", " ", "1", "2"]
//reverseString(string: &charArray)

// Lesson 4 Strings with one difference

//func isOneAwaySameLength(firstString: String, secondString: String) -> Bool {
//    var countDifferent = 0
//
//    for item in 0...firstString.count - 1 {
//        let indexFirst = firstString.index(firstString.startIndex, offsetBy: item)
//        let indexSecond = secondString.index(secondString.startIndex, offsetBy: item)
//        if firstString[indexFirst] != secondString[indexSecond] {
//            countDifferent += 1
//            if countDifferent > 1 { return false }
//        }
//    }
//    return true
//}
//
//func isOneAwayDiffLength(firstString: String, secondString: String) -> Bool {
//    var countDifferent = 0
//    var i = 0
//
//    while i < secondString.count {
//        let indexFirst = firstString.index(firstString.startIndex, offsetBy: i + countDifferent)
//        let indexSecond = secondString.index(secondString.startIndex, offsetBy: i)
//
//        if firstString[indexFirst] == secondString[indexSecond] {
//            i += 1
//        } else {
//            countDifferent += 1
//            if countDifferent > 1 {
//                return false
//            }
//        }
//    }
//    return true
//}
//
//func isOneAway(firstString: String, secondString: String) -> Bool {
//    if firstString.count - secondString.count >= 2 || secondString.count - firstString.count >= 2 {
//        return false
//    } else if firstString.count == secondString.count {
//        return isOneAwaySameLength(firstString: firstString, secondString: secondString)
//    } else if firstString.count > secondString.count {
//        return isOneAwayDiffLength(firstString: firstString, secondString: secondString)
//    } else {
//        return isOneAwayDiffLength(firstString: secondString, secondString: firstString)
//    }
//}
//
//isOneAway(firstString: "8767687", secondString: "Hello")
//isOneAway(firstString: "Hello", secondString: "Hello")
//isOneAway(firstString: "Hello", secondString: "Helpr")
//isOneAway(firstString: "Hello", secondString: "Helg")
//isOneAway(firstString: "Hello", secondString: "Hell")
//isOneAway(firstString: "Helg", secondString: "Hello")
//isOneAway(firstString: "Hell", secondString: "Hello")

// Lesson 5 Turn over LinkedList

//class ListNode {
//    var value: Int
//    var next: ListNode?
//
//    init(value: Int, next: ListNode?) {
//        self.value = value
//        self.next = next
//    }
//}
//
//let thirdNode = ListNode(value: 2, next: nil)
//let secondNode = ListNode(value: 5, next: thirdNode)
//let oneNode = ListNode(value: 3, next: secondNode)
//
//func printList(head: ListNode?) {
//    var currentNode = head
//    while currentNode != nil {
//        print(currentNode?.value ?? "")
//        currentNode = currentNode?.next
//    }
//}
//
////printList(head: oneNode)
//
//func reverseList(head: ListNode?) -> ListNode? {
//    var currentNode = head
//    var previous: ListNode?
//    var next: ListNode?
//
//    while currentNode != nil {
//        next = currentNode?.next
//        currentNode?.next = previous
//        previous = currentNode
//        currentNode = next
//    }
//    return previous
//}
//
//reverseList(head: oneNode)

// Lesson 6 Merge two sorted LinkedList

//func mergeTwoLists(firstList: ListNode?, secondList: ListNode?) -> ListNode? {
//    guard firstList != nil else { return secondList }
//    guard secondList != nil else { return firstList }
//
//    let dummyHead = ListNode(value: 0, next: nil)
//
//    var l1 = firstList, l2 = secondList
//    var endOfSortedList = dummyHead
//
//    while l1 != nil && l2 != nil {
//        if l1!.value <= l2!.value {
//            endOfSortedList.next = l1
//            l1 = l1!.next
//        } else {
//            endOfSortedList.next = l2
//            l2 = l2!.next
//        }
//        endOfSortedList = endOfSortedList.next!
//    }
//    endOfSortedList.next = l1 == nil ? l2 : l1
//    return dummyHead.next
//}
//
//
//let thirdNode = ListNode(value: 6, next: nil)
//let secondNode = ListNode(value: 5, next: thirdNode)
//let oneNode = ListNode(value: 1, next: secondNode)
//
//let thirdNode2 = ListNode(value: 8, next: nil)
//let secondNode2 = ListNode(value: 3, next: thirdNode2)
//let oneNode2 = ListNode(value: 2, next: secondNode2)
//
//var m = mergeTwoLists(firstList: oneNode, secondList: oneNode2)
//
//printList(head: m)

// Lesson 7 Linked List Data Structure and Generics

class ListNode<T> {
    var value: T
    var next: ListNode?
    var previous: ListNode?

    init(value: T) {
        self.value = value
    }
}
//
struct LinkedList<T>: CustomStringConvertible  {
    var description: String {
        var text = "["
        var node = head

        while node != nil {
            text += "\(node!.value)"
            node = node?.next
            if node != nil {
                text += ", "
            }
        }
        return text + "]"
    }

    var isEmpty: Bool {
        return head == nil
    }

    var first: ListNode<T>? {
        return head
    }

    var last: ListNode<T>? {
        return tail
    }
    
    var count: Int {
        var currentNode = head
        var count = 0
        while currentNode != nil {
            count += 1
            currentNode = currentNode?.next
        }
        return count
    }

    private var head: ListNode<T>?
    private var tail: ListNode<T>?

    mutating func append(value: T) {
        let newNode = ListNode(value: value)
        if tail != nil {
            newNode.previous = tail
            tail?.next = newNode
        } else {
            head = newNode
        }
        tail = newNode
    }

    mutating func remove(node: ListNode<T>) -> T {
        let previous = node.previous
        let next = node.next

        if let previous = previous {
            previous.next = next
        } else {
            head = next
        }
        next?.previous = previous

        if next == nil {
            tail = previous
        }
        node.previous = nil
        node.next = nil

        return node.value
    }
}
//
//var list  = LinkedList<Int>()
//
//list.append(value: 1)
//list.append(value: 2)
//list.append(value: 3)
//list.append(value: 4)
//list.append(value: 5)
//
//list.remove(node: list.first!)
//list.remove(node: list.last!)
//
//list.description
//
//var list2 = LinkedList<String>()
//
//list2.append(value: "abc")
//list2.append(value: "cdf")
//
//list2.isEmprty
//list2.first?.value
//list2.last?.value
//
//list2.description
//
//list2.remove(node: list2.last!)

// Lesson 8 Create a field with bombs in the game "Minesweeper"

//func minesweeper(bombs: [[Int]], rows: Int, columns: Int) -> [[Int]] {
//    var field = Array(repeating: Array(repeating: 0, count: columns), count: rows)
//
//    for bomb in bombs {
//        let row = bomb[0]
//        let column = bomb[1]
//        field[row][column] = -1
//
//        for i in row - 1...row + 1 {
//            for j in column - 1...column + 1 {
//                if (0 <= i) && (i < rows) && (0 <= j) && (j < columns) && (field[i][j] != -1) {
//                    field[i][j] += 1
//                }
//            }
//        }
//    }
//    return field
//}
//
//let field = minesweeper(bombs: [[0, 2], [0, 3], [2, 1]], rows: 3, columns: 4)

// Lesson 9 Queue Data Structure

struct Queue<T>: CustomStringConvertible {
    var description: String {
        return list.description
    }

    var isEmpty: Bool {
        return list.isEmpty
    }
    
    var count: Int {
        return list.count
    }

    private var list = LinkedList<T>()

    mutating func enqueue(element: T) {
        list.append(value: element)
    }

    mutating func dequeue() -> T? {
        guard !list.isEmpty, let element = list.first else { return nil }
        list.remove(node: element)
        return element.value
    }

    mutating func peek() -> T? {
        return list.first?.value
    }
}
//
//var queue = Queue<Int>()
//
//queue.enqueue(element: 3)
//queue.enqueue(element: 4)
//queue.enqueue(element: 5)
//queue.enqueue(element: 6)
//
//queue.dequeue()
//queue
//
//queue.dequeue()
//queue
//
//queue.peek()

// Lesson 10 Open the field with bombs when pressed

//func minesweeper(bombs: [[Int]], rows: Int, columns: Int) -> [[Int]] {
//    var field = Array(repeating: Array(repeating: 0, count: columns), count: rows)
//
//    for bomb in bombs {
//        let row = bomb[0]
//        let column = bomb[1]
//        field[row][column] = -1
//
//        for i in row - 1...row + 1 {
//            for j in column - 1...column + 1 {
//                if (0 <= i) && (i < rows) && (0 <= j) && (j < columns) && (field[i][j] != -1) {
//                    field[i][j] += 1
//                }
//            }
//        }
//    }
//    return field
//}
//
//var field = minesweeper(bombs: [[0, 4], [3, 1]], rows: 4, columns: 5)
//field.map { (array) in
//    print(array)
//}
//
//// Расширить доступную часть поля при нажатии
//func click(field: inout [[Int]], givenI: Int, givenJ: Int) -> [[Int]] {
//    var queue = Queue<[Int]>()
//    let rows = field.count
//    let columns = (field.first?.count)!
//
//    if field[givenI][givenJ] == 0 {
//        field[givenI][givenJ] = -2
//        queue.enqueue(element: [givenI, givenJ])
//    } else {
//        return field
//    }
//
//    while !queue.isEmpty {
//        let position = queue.dequeue()
//
//        for i in (position?.first)! - 1...(position?.first)! + 1 {
//            for j in (position?.last)! - 1...(position?.last)! + 1 {
//                if (0 <= i) && (i < rows) && (0 <= j) && (j < columns) && (field[i][j] == 0) {
//                    field[i][j] = -2
//                    queue.enqueue(element: [i, j])
//                }
//            }
//        }
//    }
//    return field
//}
//
//let newField = click(field: &field, givenI: 3, givenJ: 3)
//print("------------------")
//newField.map { (array) in
//    print(array)
//}

// Lesson 11 Search Binary Tree

class Node {
    let value: Int
    let leftChild: Node?
    let rightChild: Node?
    
    init(value: Int, leftChild: Node?, rightChild: Node?) {
        self .value = value
        self.leftChild = leftChild
        self.rightChild = rightChild
    }
}

// left branch
let secondNode = Node(value: 2, leftChild: nil, rightChild: nil)
let sixthNode = Node(value: 6, leftChild: secondNode, rightChild: nil)

// right branch
let thirteenthNode = Node(value: 13, leftChild: nil, rightChild: nil)
let twentiethNode = Node(value: 20, leftChild: nil, rightChild: nil)
let fifteenthNode = Node(value: 15, leftChild: thirteenthNode, rightChild: twentiethNode)

let headNode = Node(value: 12, leftChild: sixthNode, rightChild: fifteenthNode)

//           12
//          /  \
//         6    15
//        /    /  \
//       2    13   20

func search(node: Node?, searchValue: Int) -> Bool {
    if node == nil {
        return false
    }
    
    if node?.value == searchValue {
        return true
    } else if searchValue < node!.value {
        return search(node: node?.leftChild, searchValue: searchValue)
    } else {
        return search(node: node?.rightChild, searchValue: searchValue)
    }
}

search(node: headNode, searchValue: 13)

// Lesson 12 Max depth Binary tree

func maxDepth(head: Node?) -> Int {
    guard let head = head else { return 0 }
    var maxLevel = 0
    var queue = Queue<Node>()
    queue.enqueue(element: head)
    
    while !queue.isEmpty {
        maxLevel += 1
        let count = queue.count
        for _ in 0..<count {
            let current = queue.dequeue()
            if let left = current?.leftChild {
                queue.enqueue(element: left)
            }
            if let right = current?.rightChild {
                queue.enqueue(element: right)
            }
        }
    }
    return maxLevel
}

maxDepth(head: headNode)
